% Code for "Low Quality Retinal Blood Vessel Image Boosting Using Fuzzified Clustering"

% Degree of fuzzification   m=2;   
% Number of clusters        c=2;

For execution of code please see the Example_code.m file  
